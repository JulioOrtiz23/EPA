<!-- no tiene color -->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="footer-text">Copyright © 2022 - EPA</p>
            </div>
        </div>
    </div>
</footer>

<script src="<?php echo base_url; ?>Assets/js/jquery-3.6.0.min.js"></script>
<!-- Scripts -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js?ver=1.4.2"></script>
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
</script>
<!--Jquery y Bootstrap bundle-->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
<!-- Bootstrap core JavaScript -->
<script src="<?php echo base_url; ?>Assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url; ?>Assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url; ?>Assets/js/scripts.js"></script>
<script src="<?php echo base_url; ?>Assets/js/owl-carousel.js"></script>
<script src="<?php echo base_url; ?>Assets/js/tabs.js"></script>
<script src="<?php echo base_url; ?>Assets/js/popup.js"></script>
<!-- <script src="<?php echo base_url; ?>Assets/js/custom.js"></script> -->